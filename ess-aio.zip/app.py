from __future__ import annotations

from pathlib import Path

from bms_logger.release_manager import install_crash_handler
from bms_logger.ui import run


if __name__ == "__main__":
    install_crash_handler(Path.cwd() / "logs")
    run()
