from __future__ import annotations

from typing import Any, Dict

from .base import DriverInfo
from ..modbus_client import BmsModbusClient
from ..pcs_client import PcsClient


INFO_BMS = DriverInfo(
    key="catl_v22_bms",
    name="CATL TenerS/TenerX V22 BMS",
    device_type="BMS",
    vendor="CATL",
    description="CATL V22 Modbus driver loaded from JSON point table; keeps legacy UI aliases.",
)

INFO_PCS = DriverInfo(
    key="generic_modbus_pcs",
    name="Generic Modbus PCS",
    device_type="PCS",
    vendor="Generic",
    description="Config-driven PCS Modbus driver using pcs_config.json points.",
)


def create_bms(config: Dict[str, Any]):
    return BmsModbusClient(
        host=config["host"],
        port=int(config.get("port", 502)),
        unit_id=int(config.get("unit_id", 1)),
        timeout=float(config.get("timeout", 3.0)),
        protocol=str(config.get("driver", "catl_v22_bms")),
        point_table_path=config.get("point_table_path"),
    )


def create_pcs(config: Dict[str, Any]):
    return PcsClient(config=config)
