from __future__ import annotations

from pathlib import Path
import csv
from PySide6.QtCharts import QChart, QChartView, QLineSeries, QValueAxis
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
    QMessageBox,
    QSizePolicy,
)

def _build_devices_tab(self, tabs: QTabWidget) -> None:
        device_tab = QWidget()
        device_layout = QVBoxLayout(device_tab)
        device_layout.setContentsMargins(14, 14, 14, 14)
        device_layout.setSpacing(12)

        form_wrap = QGroupBox("Device Config")
        form = QGridLayout(form_wrap)

        self.name_edit = QLineEdit("BMS-1")
        self.host_edit = QLineEdit("127.0.0.1")

        self.port_spin = QSpinBox()
        self.port_spin.setRange(1, 65535)
        self.port_spin.setValue(502)

        self.unit_spin = QSpinBox()
        self.unit_spin.setRange(0, 255)
        self.unit_spin.setValue(1)

        self.interval_spin = QDoubleSpinBox()
        self.interval_spin.setRange(0.2, 3600.0)
        self.interval_spin.setDecimals(1)
        self.interval_spin.setValue(2.0)
        self.interval_spin.setSuffix(" s")

        self.bms_fake_scenario_combo = QComboBox()
        self.bms_fake_scenario_combo.addItems(["normal", "high_voltage", "low_voltage", "offline", "fault", "alarm"])

        self.output_dir_edit = QLineEdit(str(self.get_profile_path("output")))
        self.output_dir_btn = QPushButton("Browse...")
        self.output_dir_btn.clicked.connect(self.choose_output_dir)

        out_row = QWidget()
        out_layout = QHBoxLayout(out_row)
        out_layout.setContentsMargins(0, 0, 0, 0)
        out_layout.addWidget(self.output_dir_edit)
        out_layout.addWidget(self.output_dir_btn)

        fields = [
            ("Device name", self.name_edit),
            ("Host", self.host_edit),
            ("Port", self.port_spin),
            ("Unit ID", self.unit_spin),
            ("Sample interval", self.interval_spin),
            ("Fake scenario", self.bms_fake_scenario_combo),
            ("Output dir", out_row),
        ]

        for i, (title, widget) in enumerate(fields):
            row = i // 3
            col = (i % 3) * 2
            form.addWidget(QLabel(title), row, col)
            form.addWidget(widget, row, col + 1)

        device_layout.addWidget(form_wrap)

        btn_row = QHBoxLayout()
        self.add_device_btn = QPushButton("Add device")
        self.add_device_btn.clicked.connect(self.add_device)

        self.start_selected_btn = QPushButton("Start selected")
        self.start_selected_btn.clicked.connect(self.start_selected_device)

        self.stop_selected_btn = QPushButton("Stop selected")
        self.stop_selected_btn.clicked.connect(self.stop_selected_device)

        self.start_btn = QPushButton("Start all")
        self.start_btn.clicked.connect(self.start_all)

        self.stop_btn = QPushButton("Stop all")
        self.stop_btn.clicked.connect(self.stop_all)

        self.remove_device_btn = QPushButton("Remove selected BMS")
        self.remove_device_btn.clicked.connect(self.remove_selected_device)

        btn_row.addWidget(self.add_device_btn)
        btn_row.addWidget(self.remove_device_btn)
        btn_row.addWidget(self.start_selected_btn)
        btn_row.addWidget(self.stop_selected_btn)
        btn_row.addWidget(self.start_btn)
        btn_row.addWidget(self.stop_btn)
        btn_row.addStretch()
        device_layout.addLayout(btn_row)

        self.device_table = QTableWidget(0, 13)
        self.device_table.setHorizontalHeaderLabels(
            [
                "Name",
                "Host",
                "Port",
                "Unit ID",
                "Interval(s)",
                "BMS Status",
                "Racks",
                "SOC(%)",
                "Voltage(V)",
                "Current(A)",
                "Power(kW)",
                "Run State",
                "Online",
            ]
        )
        header = self.device_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeToContents)
        header.setStretchLastSection(True)
        self.device_table.cellClicked.connect(self.on_device_table_clicked)
        device_layout.addWidget(self.device_table)

        tabs.addTab(device_tab, "Devices")

