from __future__ import annotations

import json
import csv
from collections import deque
from pathlib import Path
from typing import Any, Dict

from PySide6.QtCharts import QChart, QLineSeries
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QFileDialog, QMessageBox, QTableWidgetItem, QInputDialog
from PySide6.QtGui import QColor





class DataReceiveMixin:
    def on_error_received(self, device_name: str, error: str) -> None:
        row = self.device_rows.get(device_name)
        if row is not None:
            run_item = QTableWidgetItem("Error")
            self._set_table_item_color(run_item, "Error")
            self.device_table.setItem(row, 11, run_item)

            online_item = QTableWidgetItem("Offline")
            self._set_table_item_color(online_item, "Offline")
            self.device_table.setItem(row, 12, online_item)

        self.last_error_message = f"{device_name}: {error}"
        self.refresh_global_status_bar()

        idx = self.sample_index[device_name]
        self.sample_index[device_name] += 1
        self.series_buffers[device_name]["online"].append((idx, 0.0))

        if self.current_curve_device == device_name:
            self.refresh_curves(device_name)

        self.log(f"[ERROR] {device_name}: {error}")

    def on_heartbeat_written(self, device_name: str, value: int) -> None:
        if self.current_control_device == device_name:
            self.heartbeat_state_label.setText(f"Running ({value})")
            self.control_state_label.setText("Running")
            self.last_control_result_label.setText(f"Heartbeat={value}")

        self.last_heartbeat_status = f"Running ({value})"
        self.refresh_global_status_bar()

    def on_heartbeat_error(self, device_name: str, error: str) -> None:
        if self.current_control_device == device_name:
            self.heartbeat_state_label.setText("Error")
            self.control_state_label.setText("Failed")
            self.last_control_result_label.setText(error)

        self.last_heartbeat_status = "Error"
        self.last_error_message = f"{device_name}: {error}"
        self.refresh_global_status_bar()

        self.control_log(f"[CONTROL] {device_name}: {error}")

    def on_hv_workflow_log(self, device_name: str, message: str) -> None:
        if "SUCCESS" in message:
            self.last_hv_status = "Success"
        elif "FAIL" in message:
            self.last_hv_status = "Failed"
        elif "TIMEOUT" in message:
            self.last_hv_status = "Timeout"
        elif "CANCELLED" in message:
            self.last_hv_status = "Cancelled"
        else:
            self.last_hv_status = "Running"

        self.refresh_global_status_bar()
        self.control_log(f"[{device_name}] {message}")

    def on_hv_workflow_finished(self, device_name: str, mode: str, success: bool) -> None:
        self.hv_workers.pop(device_name, None)

        mode_text = "HV ON" if mode == "on" else "HV OFF"

        if success:
            self.control_state_label.setText("Done")
            self.last_control_result_label.setText(f"{mode_text} success")
            self.last_hv_status = "Success"
            self.control_log(f"[CONTROL] {device_name}: {mode_text} workflow finished successfully")
        else:
            self.control_state_label.setText("Failed")
            self.last_control_result_label.setText(f"{mode_text} failed")
            self.last_hv_status = "Failed"
            self.control_log(f"[CONTROL] {device_name}: {mode_text} workflow finished with failure")

        self.refresh_global_status_bar()


    def on_data_received(self, device_name: str, snapshot: Dict[str, Any]) -> None:
        recorder = self.recorders.get(device_name)
        if recorder:
            recorder.write_row(snapshot)

        parsed_alarm = self.alarm_parser.parse_snapshot(snapshot)

        alarm_recorder = self.alarm_recorders.get(device_name)
        if alarm_recorder:
            alarm_recorder.write_row(device_name, snapshot, parsed_alarm)

        self.latest_snapshots[device_name] = snapshot
        online_state = self.evaluate_bms_online_state(device_name, snapshot)
        self.service.on_snapshot(device_name, snapshot, self)

        row = self.device_rows.get(device_name)
        if row is not None:
            self.device_table.item(row, 5).setText(str(snapshot.get("bms_status", "-")))
            self.device_table.item(row, 6).setText(str(snapshot.get("number_of_racks", "-")))
            self.device_table.item(row, 7).setText(str(snapshot.get("soc", "-")))
            self.device_table.item(row, 8).setText(str(snapshot.get("system_voltage", "-")))
            self.device_table.item(row, 9).setText(str(snapshot.get("system_current", "-")))
            self.device_table.item(row, 10).setText(str(snapshot.get("system_power", "-")))
            run_item = QTableWidgetItem("Running")
            self._set_table_item_color(run_item, "Running")
            self.device_table.setItem(row, 11, run_item)

            online_item = QTableWidgetItem(online_state)
            self._set_table_item_color(online_item, online_state)
            self.device_table.setItem(row, 12, online_item)

        self.recent_buffers[device_name].append(snapshot)

        idx = self.sample_index[device_name]
        self.sample_index[device_name] += 1

        # v3.0 phase 3: store every numeric driver point for dynamic plotting.
        points = snapshot.get("points", {}) if isinstance(snapshot.get("points"), dict) else snapshot
        for point_key, point_value in points.items():
            if point_key in {"timestamp", "raw", "point_meta", "points"}:
                continue
            try:
                numeric_value = float(point_value)
            except (TypeError, ValueError):
                continue
            self.dynamic_point_buffers[device_name][str(point_key)].append((idx, numeric_value))

        # Heavy UI refresh is throttled; buffers still update at full sampling rate.

        self.series_buffers[device_name]["soc"].append((idx, float(snapshot.get("soc", 0))))
        self.series_buffers[device_name]["system_voltage"].append(
            (idx, float(snapshot.get("system_voltage", 0)))
        )
        self.series_buffers[device_name]["system_current"].append(
            (idx, float(snapshot.get("system_current", 0)))
        )

        online_value = 1.0 if online_state == "Online" else 0.0
        self.series_buffers[device_name]["online"].append((idx, online_value))

        if self.current_curve_device is None:
            self.current_curve_device = device_name
            self.curve_device_combo.setCurrentText(device_name)
            self.curve_device_label.setText(f"Current device: {device_name}")

        if self.current_detail_device is None:
            self.current_detail_device = device_name
            self.detail_device_combo.setCurrentText(device_name)
            self.detail_device_label.setText(f"Current device: {device_name}")

        if self.current_alarm_device is None:
            self.current_alarm_device = device_name
            self.alarm_device_combo.setCurrentText(device_name)
            self.alarm_device_label.setText(f"Current device: {device_name}")

        if self.current_control_device is None:
            self.current_control_device = device_name
            self.control_device_combo.setCurrentText(device_name)
            self.control_device_label.setText(f"Current device: {device_name}")

        import time
        now = time.time()
        last_ui = self._last_ui_refresh_time.get(device_name, 0.0) if hasattr(self, "_last_ui_refresh_time") else 0.0
        interval = float(getattr(self, "ui_refresh_interval", 1.0))
        if now - last_ui < interval:
            return
        if hasattr(self, "_last_ui_refresh_time"):
            self._last_ui_refresh_time[device_name] = now

        if self.current_curve_device == device_name:
            self.refresh_curves(device_name)

        if self.current_detail_device == device_name:
            self.refresh_details(device_name)

        if hasattr(self, "driver_points_device_combo") and self.driver_points_device_combo.currentText() == device_name:
            self.refresh_driver_points(device_name)

        if self.current_alarm_device == device_name:
            self.refresh_alarms(device_name)

    def on_curve_device_changed(self, device_name: str) -> None:
        if device_name:
            self.refresh_curves(device_name)

    def on_detail_device_changed(self, device_name: str) -> None:
        if device_name:
            self.refresh_details(device_name)

    def on_alarm_device_changed(self, device_name: str) -> None:
        if device_name:
            self.refresh_alarms(device_name)

    def on_control_device_changed(self, device_name: str) -> None:
        if not device_name:
            return

        self.current_control_device = device_name
        self.control_device_label.setText(f"Current device: {device_name}")

        if device_name in self.heartbeat_workers:
            self.heartbeat_state_label.setText("Running")
            self.control_state_label.setText("Running")
        else:
            self.heartbeat_state_label.setText("Stopped")
            self.control_state_label.setText("Idle")

        for label in self.pcs_status_labels.values():
            label.setText("-")

        self.refresh_global_status_bar()

    def on_device_table_clicked(self, row: int, column: int) -> None:
        _ = column
        item = self.device_table.item(row, 0)
        if item is None:
            return

        device_name = item.text()
        if not device_name:
            return

        self.curve_device_combo.setCurrentText(device_name)
        if hasattr(self, "driver_points_device_combo"):
            self.driver_points_device_combo.setCurrentText(device_name)
        self.detail_device_combo.setCurrentText(device_name)
        self.alarm_device_combo.setCurrentText(device_name)
        self.control_device_combo.setCurrentText(device_name)

        self.refresh_curves(device_name)
        if hasattr(self, "driver_points_table"):
            self.refresh_driver_points(device_name)
        self.refresh_details(device_name)
        self.refresh_alarms(device_name)

    def evaluate_bms_online_state(self, device_name: str, snapshot: Dict[str, Any]) -> str:
        heartbeat = snapshot.get("bms_heartbeat")

        if heartbeat is None:
            return "Unknown"

        try:
            heartbeat_int = int(heartbeat)
        except (TypeError, ValueError):
            return "Unknown"

        last = self.bms_last_heartbeat.get(device_name)

        if last is None:
            self.bms_last_heartbeat[device_name] = heartbeat_int
            self.bms_heartbeat_same_count[device_name] = 0
            return "Online"

        delta = (heartbeat_int - last) % 256
        if 0 < delta <= 5:
            self.bms_last_heartbeat[device_name] = heartbeat_int
            self.bms_heartbeat_same_count[device_name] = 0
            return "Online"

        if heartbeat_int == last:
            same_count = self.bms_heartbeat_same_count.get(device_name, 0) + 1
            self.bms_heartbeat_same_count[device_name] = same_count

            if same_count >= 3:
                return "Stale"
            return "Online"

        self.bms_last_heartbeat[device_name] = heartbeat_int
        self.bms_heartbeat_same_count[device_name] = 0
        return "Stale"

