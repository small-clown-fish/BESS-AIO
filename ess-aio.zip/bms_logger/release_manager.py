from __future__ import annotations

import json
import shutil
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any

from .version import APP_NAME, APP_VERSION, BUILD_ID, PROFILE_SCHEMA_VERSION, version_dict


DEFAULT_RUNTIME_CONFIG: dict[str, Any] = {
    "heartbeat_interval": 1.0,
    "hv_step_timeout": 30.0,
    "hv_poll_interval": 1.0,
    "pcs_zero_power_threshold": 0.1,
    "charge_cutoff_max_cell_voltage": 3650.0,
    "discharge_cutoff_min_cell_voltage": 2500.0,
    "cutoff_mode": "Alarm Only",
    "cutoff_trigger_confirm_count": 3,
    "cutoff_recover_confirm_count": 3,
    "alarm_history_window_before_minutes": 5,
    "alarm_history_window_after_minutes": 5,
    "power_tracking_enabled": True,
    "power_tracking_tolerance_kw": 5.0,
    "power_tracking_confirm_count": 3,
    "pcs_fault_protection_mode": "Alarm Only",
    "pcs_fault_confirm_count": 3,
    "fake_mode": False,
    "worker_start_stagger_seconds": 0.25,
    "ui_refresh_interval": 1.0,
}

DEFAULT_STRATEGY: dict[str, Any] = {
    "enabled": True,
    "runtime_overrides": {},
    "rules": [],
}

DEFAULT_DRIVER_CONFIG: dict[str, Any] = {
    "bms_driver": "catl_v17_bms",
    "pcs_driver": "generic_modbus_pcs",
}

DEFAULT_SITE_CONFIG: dict[str, Any] = {
    "site": "Default Site",
    "clusters": [
        {"name": "Cluster-1", "bms_devices": [], "pcs_device": "PCS-1"}
    ],
}

DEFAULT_PCS_CONFIG: dict[str, Any] = {
    "PCS-1": {
        "name": "PCS-1",
        "enabled": False,
        "host": "192.168.1.100",
        "port": 502,
        "unit_id": 1,
        "timeout": 3.0,
        "driver": "generic_modbus_pcs",
        "points": {
            "dc_breaker_status": {"register_type": "holding", "address": 1000, "open_value": 0, "closed_value": 1, "scale": 1.0, "offset": 0.0},
            "active_power": {"register_type": "holding", "address": 1001, "scale": 0.1, "offset": 0.0},
            "start_cmd": {"register_type": "holding", "address": 2000, "write_value": 1},
            "stop_cmd": {"register_type": "holding", "address": 2001, "write_value": 1},
            "reset_fault_cmd": {"register_type": "holding", "address": 2002, "write_value": 1},
            "hv_on_cmd": {"register_type": "holding", "address": 2003, "write_value": 1},
            "hv_off_cmd": {"register_type": "holding", "address": 2004, "write_value": 1},
            "close_dc_breaker_cmd": {"register_type": "holding", "address": 2005, "write_value": 1},
            "open_dc_breaker_cmd": {"register_type": "holding", "address": 2006, "write_value": 1},
            "set_active_power": {"register_type": "holding", "address": 2010, "scale": 0.1, "offset": 0.0},
        },
    }
}


class StartupSelfCheckResult:
    def __init__(self) -> None:
        self.created: list[str] = []
        self.migrated: list[str] = []
        self.warnings: list[str] = []
        self.errors: list[str] = []

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_text(self) -> str:
        lines = ["Startup Self Check", f"Status: {'OK' if self.ok else 'ERROR'}"]
        for title, items in [
            ("Created", self.created),
            ("Migrated", self.migrated),
            ("Warnings", self.warnings),
            ("Errors", self.errors),
        ]:
            lines.append("")
            lines.append(title + ":")
            if items:
                lines.extend(f"  - {item}" for item in items)
            else:
                lines.append("  - none")
        return "\n".join(lines)


def _read_json(path: Path, default: Any) -> Any:
    try:
        if not path.exists():
            return default
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _merge_defaults(existing: dict[str, Any], defaults: dict[str, Any]) -> tuple[dict[str, Any], bool]:
    changed = False
    merged = dict(existing)
    for key, value in defaults.items():
        if key not in merged:
            merged[key] = value
            changed = True
    return merged, changed


def ensure_profile(profile_dir: Path, project_root: Path | None = None) -> StartupSelfCheckResult:
    """Create missing profile files and migrate old profile structures in-place."""
    result = StartupSelfCheckResult()
    profile_dir.mkdir(parents=True, exist_ok=True)

    for subdir in ["logs", "output", "reports", "debug_packages", "point_tables"]:
        path = profile_dir / subdir
        if not path.exists():
            path.mkdir(parents=True, exist_ok=True)
            result.created.append(str(path))

    manifest_path = profile_dir / "profile_manifest.json"
    manifest = _read_json(manifest_path, {})
    manifest_defaults = {
        "app": APP_NAME,
        "app_version": APP_VERSION,
        "build_id": BUILD_ID,
        "profile_schema_version": PROFILE_SCHEMA_VERSION,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }
    manifest, manifest_changed = _merge_defaults(manifest if isinstance(manifest, dict) else {}, manifest_defaults)
    manifest["app_version"] = APP_VERSION
    manifest["build_id"] = BUILD_ID
    manifest["profile_schema_version"] = PROFILE_SCHEMA_VERSION
    manifest["updated_at"] = datetime.now().isoformat(timespec="seconds")
    _write_json(manifest_path, manifest)
    if manifest_changed or not manifest_path.exists():
        result.created.append(str(manifest_path))

    file_defaults = {
        "runtime_config.json": DEFAULT_RUNTIME_CONFIG,
        "strategy.json": DEFAULT_STRATEGY,
        "driver_config.json": DEFAULT_DRIVER_CONFIG,
        "site_config.json": DEFAULT_SITE_CONFIG,
        "devices.json": [],
        "pcs_configs.json": DEFAULT_PCS_CONFIG,
        "alarm_map.json": {},
    }

    for filename, defaults in file_defaults.items():
        path = profile_dir / filename
        if not path.exists():
            _write_json(path, defaults)
            result.created.append(str(path))
            continue

        if isinstance(defaults, dict):
            current = _read_json(path, {})
            if not isinstance(current, dict):
                result.warnings.append(f"{filename} is not a JSON object; left unchanged")
                continue
            merged, changed = _merge_defaults(current, defaults)
            if changed:
                backup = path.with_suffix(path.suffix + f".bak_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
                shutil.copy2(path, backup)
                _write_json(path, merged)
                result.migrated.append(f"{filename} (backup: {backup.name})")

    # Copy bundled point-table templates into profile if docs are present.
    if project_root is not None:
        docs_dir = project_root / "docs"
        target_dir = profile_dir / "point_tables"
        if docs_dir.exists():
            for src in docs_dir.glob("*.json"):
                if "point_table" in src.name.lower() or "catl" in src.name.lower():
                    dst = target_dir / src.name
                    if not dst.exists():
                        shutil.copy2(src, dst)
                        result.created.append(str(dst))

    selfcheck_path = profile_dir / "logs" / f"startup_selfcheck_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    try:
        selfcheck_path.write_text(result.to_text(), encoding="utf-8")
    except Exception:
        pass

    return result


def install_crash_handler(log_dir: Path | None = None) -> None:
    """Install a global crash logger for uncaught exceptions."""
    import sys

    if log_dir is None:
        log_dir = Path.cwd() / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    original_hook = sys.excepthook

    def _hook(exc_type, exc_value, exc_tb):
        try:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            crash_path = log_dir / f"app_crash_{stamp}.log"
            with open(crash_path, "w", encoding="utf-8") as f:
                f.write(f"{APP_NAME} v{APP_VERSION}\n")
                f.write(f"Build: {BUILD_ID}\n")
                f.write(f"Time: {datetime.now().isoformat(timespec='seconds')}\n\n")
                traceback.print_exception(exc_type, exc_value, exc_tb, file=f)
        except Exception:
            pass
        original_hook(exc_type, exc_value, exc_tb)

    sys.excepthook = _hook
